# Group-F
This repository is used to build a fullstack web app for the course COMP424 Group F project.
Group Members:
1. Chandrika Darbha
2. Samuel Gebre Habte
3. Alfaisal Qasem M Alqahtani
