$('.menu-toggle').click(function() {

  $('.site-nav').toggleClass('site-nav--open');
  $(this).toggleClass('open');

})
