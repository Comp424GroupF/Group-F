Rental property CRM static pages under progress. When done it will be integrated in to express and mongodb. Next Step is to design forms
for data manipulation. Future, CRUD will be tested once done development.
