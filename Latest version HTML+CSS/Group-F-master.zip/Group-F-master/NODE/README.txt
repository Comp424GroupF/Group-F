Node, express and mongo login, registration and logout app done.
Used Passport and passport-local for Authentication and for hashing bscryptjs for paswword hashing.
Next step: continue building announcement, service request functionalities.
